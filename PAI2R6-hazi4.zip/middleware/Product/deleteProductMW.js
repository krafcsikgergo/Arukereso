
/**
 * Deletes a product from the database
 * @param {*} objectrepository 
 * @returns 
 */
module.exports = function (objectrepository) {
  return function (req, res, next) {
    //TODO
    next();
  };
};
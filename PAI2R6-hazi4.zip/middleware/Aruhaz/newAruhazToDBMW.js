
/**
 * Saves the new aruhaz to the database
 * @param {*} objectrepository 
 * @returns 
 */
module.exports = function (objectrepository) {
  return function (req, res, next) {
    //TODO
    next();
  };
};


/**
 * Deletes Aruhaz from the database
 * @param {*} objectrepository 
 */
module.exports = function (objectrepository) {
    return function (req, res, next) {
        //TODO
        next();
    };
};